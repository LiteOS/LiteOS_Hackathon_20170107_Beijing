#include "stdio.h"
#include "serial_api.h"
#include "gpio_api.h"
#include "rtc_api.h"
#include "version.h"

#include "cmsis_os.h"


#define LED_GPIO_ON     0
#define LED_GPIO_OFF    1


extern void gps_uart_recv(uint8_t c);
extern void gps_reset(void);

extern void comm_ring_buf_put(uint8_t c);
extern void comm_ring_buf_init(void);

extern void modbus_recv(uint8_t c);
extern void modbus_send(void);

extern void ht_m_slave_recv(uint8_t c);
extern void ht_m_slave_send(void);

extern void ht_gsm_uart_send(void);
extern void ht_at_uart_recv(uint8_t c);

static gpio_t  _pwr_en;
static gpio_t  _pwr_key;
static gpio_t  _modbus_cts;

static gpio_t  _led_net;
static gpio_t  _led_com;
static gpio_t  _led_alm;
static gpio_t  _led_low;
static gpio_t  _led_mid;
static gpio_t  _led_hig;
static gpio_t  _gps_pwr;

static serial_t _gsm_port;      // gprs port
#if GPRS_DEBUG
static serial_t _debug_port;    // capture external data or debug info output
#endif
static serial_t _modbus_port;   // modbus port
static serial_t _gps_uart;      // gps port
static serial_t _ht_port;       // hardware test port
static serial_t _at_uart;       // hardware test at uart
static serial_t _gsm_uart;      // hardware test gsm uart


/******************* comm api ************************/
static void _uart_irq_handler(uint32_t id, SerialIrq event)
{
    serial_t  *gsm_port =(serial_t  *) id;
    char c;
    
    if(event == RxIrq)
    {
        c = serial_getc(gsm_port);
#if GPRS_DEBUG
        serial_putc(&_debug_port, c);
#endif
        comm_ring_buf_put(c);
    }

    return ;
}

static void _serial_rcv_irq_init(serial_t  *uart)
{
    comm_ring_buf_init();
    serial_irq_handler(uart, _uart_irq_handler, (uint32_t)uart);
    serial_irq_set(uart, RxIrq, 1);
    
    return ;
}

void COMM_Putc(uint8_t c)
{
    serial_putc(&_gsm_port, c);
}

void COMM_Puts(uint8_t *s)
{
    while(*s )
    {
        serial_putc(&_gsm_port, *s);
        s++;
    }

}

uint8_t COMM_CarrierDetected(void)
{
    return 0;
}

void MODEM_RTS_Set(void)
{
    //RTS_PIN_SET;
}
void MODEM_RTS_Clr(void)
{
    //RTS_PIN_CLR;
}

void MODEM_DTR_Set(void)
{
    //DTR_PIN_SET;
}
void MODEM_DTR_Clr(void)
{
    //DTR_PIN_CLR;
}

void MODEM_MOSFET_On(void)
{
    gpio_write(&_pwr_en, 1);
}

void MODEM_MOSFET_Off(void)
{
    gpio_write(&_pwr_en, 0);
}

void MODEM_POWER_Set(void)
{
    //POWER_PIN_SET;
}

void MODEM_POWER_Clr(void)
{
    //POWER_PIN_CLR;
}

void MODEM_RESET_Set(void)
{
    //RESET_PIN_SET;
}

void MODEM_RESET_Clr(void)
{
    //RESET_PIN_CLR;
}
                
void MODEM_UartInit(uint32_t baudrate)
{
#if GPRS_DEBUG
    serial_init(&_debug_port, DEBUG_TX, DEBUG_RX);
    serial_format(&_debug_port, 8, ParityNone, 1);
    serial_baud(&_debug_port, 115200);
#endif
    serial_init(&_gsm_port, GSM_TX, GSM_RX);
    serial_format(&_gsm_port, 8, ParityNone, 1);
    serial_baud(&_gsm_port, 115200);
    _serial_rcv_irq_init(&_gsm_port);


    gpio_init(&_pwr_en, PWR_EN);
    gpio_mode(&_pwr_en, PullNone);
    gpio_dir(&_pwr_en,  PIN_OUTPUT);
    
    gpio_init_out_ex(&_pwr_key, PWR_KEY, 0);
}

/******************** modbus api ************************/
int get_baudrate_by_int(int baud)
{
    int baudrate = 9600;
    
    if(baud == 300)
    {
        baudrate = baud;
    }
    else if(baud == 600)
    {
        baudrate = baud;
    }
    else if(baud == 1200)
    {
        baudrate = baud;
    }
    else if(baud == 4800)
    {
        baudrate = baud;
    }
    else if(baud == 9600)
    {
        baudrate = baud;
    }
    else if(baud == 19200)
    {
        baudrate = baud;
    }
    else if(baud == 38400)
    {
        baudrate = baud;
    }
    else if(baud == 57600)
    {
        baudrate = baud;
    }
    else if(baud == 115200)
    {
        baudrate = baud;
    }
    else
    {
        baudrate = 9600;
    }
    
    return baudrate;
}

int get_data_bit_by_int(int data)
{
    int data_bit = 8;
    
    if(data == 7)
    {
        data_bit = data;
    }
    else if(data == 8)
    {
        data_bit = data;
    }
    else
    {
        data_bit = 8;
    }
    
    return data_bit;
}

int get_parity_by_char(char c)
{
    int parity = ParityNone;
    
    if(c == 'N')
    {
        parity = ParityNone;
    }
    else if(c == 'O')
    {
        parity = ParityOdd;
    }
    else if(c == 'F')
    {
        parity = ParityForced1;
    }
    else if(c == 'E')
    {
        parity = ParityEven;
    }
    else
    {
        parity = ParityNone;
    }
    
    return parity;
}

int get_stop_bit_by_int(int stop)
{
    int stop_bit = 1;
    
    if(stop == 1)
    {
        stop_bit = stop;
    }
    else if(stop == 2)
    {
        stop_bit = stop;
    }
    else
    {
        stop_bit = 1;
    }
    
    return stop_bit;
}

void modbus_switch(uint8_t dir)
{
    if(SCI1_CTS != NC)
    {
        if(dir == MODBUS_SEND)
        {
            gpio_write(&_modbus_cts, 1);
        }
        else
        {
            gpio_write(&_modbus_cts, 0);
        }
    }
}

void switch_init(void)
{
    if(SCI1_CTS != NC)
    {
        gpio_init(&_modbus_cts, SCI1_CTS);
        gpio_mode(&_modbus_cts, PullNone);
        gpio_dir(&_modbus_cts,  PIN_OUTPUT);
        modbus_switch(MODBUS_RECV);
    }
}

void modbus_irq_handler(uint32_t id, SerialIrq event)
{
    uint8_t c = 0;
    serial_t *modbus =(serial_t  *) id;
    
    if(event == RxIrq)
    {
        c = serial_getc(modbus);
        modbus_recv(c);
    }
    
    if(event == TxIrq)
    {
        modbus_send();
    }
}

void modbus_send_enable(void)
{
    serial_irq_set(&_modbus_port, TxIrq, 1);
}

void modbus_send_disable(void)
{
    serial_irq_set(&_modbus_port, TxIrq, 0);
}

void modbus_send_byte(uint8_t c)
{
    serial_putc(&_modbus_port, c);
}

void modbus_uart_init(int baudrate, int data_bits, SerialParity parity, int stop_bits)
{
    // modbus switch init
    switch_init();

    // modbus port init
    serial_init(&_modbus_port, SCI1_TX, SCI1_RX);
    
    serial_format(&_modbus_port, data_bits, parity, stop_bits);
    serial_baud(&_modbus_port, baudrate);

    serial_irq_handler(&_modbus_port, modbus_irq_handler, (uint32_t)&_modbus_port);
    serial_irq_set(&_modbus_port, RxIrq, 1);
    serial_irq_set(&_modbus_port, TxIrq, 0);
}

/**************** hardware test api *********************/
void ht_m_slave_irq_handler(uint32_t id, SerialIrq event)
{
    uint8_t c = 0;
    serial_t *slave =(serial_t  *) id;
    
    if(event == RxIrq)
    {
        c = serial_getc(slave);
        ht_m_slave_recv(c);
    }
    
    if(event == TxIrq)
    {
        ht_m_slave_send();
    }
}

void ht_m_slave_send_enable(void)
{
    serial_irq_set(&_ht_port, TxIrq, 1);
}

void ht_m_slave_send_disable(void)
{
    serial_irq_set(&_ht_port, TxIrq, 0);
}

void ht_m_slave_send_byte(uint8_t c)
{
    serial_putc(&_ht_port, c);
}

void ht_m_slave_uart_init(void)
{
    serial_init(&_ht_port, SCI0_TX, SCI0_RX);
    
    serial_format(&_ht_port, 8, ParityEven, 1);
    serial_baud(&_ht_port, 19200);

    serial_irq_handler(&_ht_port, ht_m_slave_irq_handler, (uint32_t)&_ht_port);
    serial_irq_set(&_ht_port, RxIrq, 1);
    serial_irq_set(&_ht_port, TxIrq, 0);
}

/**************** gsm at command api ********************/
void ht_at_uart_irq_handler(uint32_t id, SerialIrq event)
{
    uint8_t c = 0;
    serial_t *uart =(serial_t  *)id;
    
    if(event == RxIrq)
    {
        c = serial_getc(uart);
        ht_at_uart_recv(c);
    }
}

void ht_gsm_uart_irq_handler(uint32_t id, SerialIrq event)
{
    uint8_t c = 0;
    serial_t *uart =(serial_t  *)id;
    
    if(event == RxIrq)
    {
        c = serial_getc(uart);
        serial_putc(&_at_uart, c);
    }
    
    if(event == TxIrq)
    {
        ht_gsm_uart_send();
    }
}

void ht_gsm_uart_send_enable(void)
{
    serial_irq_set(&_gsm_uart, TxIrq, 1);
}

void ht_gsm_uart_send_disable(void)
{
    serial_irq_set(&_gsm_uart, TxIrq, 0);
}

void ht_gsm_uart_send_byte(uint8_t c)
{
    serial_putc(&_gsm_uart, c);
}

void ht_at_uart_send(uint8_t *buf, uint16_t len)
{
    int i = 0;
    
    for(i=0; i<len; i++)
    {
        serial_putc(&_at_uart, buf[i]);
    }
}

void ht_gsm_at_uart_init(void)
{
    // at uart init
    serial_init(&_at_uart, SCI1_TX, SCI1_RX);
    serial_format(&_at_uart, 8, ParityNone, 1);
    serial_baud(&_at_uart, 115200);

    serial_irq_handler(&_at_uart, ht_at_uart_irq_handler, (uint32_t)&_at_uart);
    serial_irq_set(&_at_uart, RxIrq, 1);
    serial_irq_set(&_at_uart, TxIrq, 0);
    
    // gsm uart init
    serial_init(&_gsm_uart, GSM_TX, GSM_RX);
    serial_format(&_gsm_uart, 8, ParityNone, 1);
    serial_baud(&_gsm_uart, 115200);

    serial_irq_handler(&_gsm_uart, ht_gsm_uart_irq_handler, (uint32_t)&_gsm_uart);
    serial_irq_set(&_gsm_uart, RxIrq, 1);
    serial_irq_set(&_gsm_uart, TxIrq, 0);

    gpio_init(&_pwr_en, PWR_EN);
    gpio_mode(&_pwr_en, PullNone);
    gpio_dir(&_pwr_en,  PIN_OUTPUT);
    
    gpio_init_out_ex(&_pwr_key, PWR_KEY, 0);
}

/****************** led flash api ***********************/
void led_gpio_init(void)
{
    gpio_init(&_led_net, LED_NET);
    gpio_mode(&_led_net, PullNone);
    gpio_dir(&_led_net,  PIN_OUTPUT);
    gpio_write(&_led_net, LED_GPIO_OFF);
    
    gpio_init(&_led_com, LED_COM);
    gpio_mode(&_led_com, PullNone);
    gpio_dir(&_led_com,  PIN_OUTPUT);
    gpio_write(&_led_com, LED_GPIO_OFF);
    
    gpio_init(&_led_alm, LED_ALM);
    gpio_mode(&_led_alm, PullNone);
    gpio_dir(&_led_alm,  PIN_OUTPUT);
    gpio_write(&_led_alm, LED_GPIO_OFF);
    
    gpio_init(&_led_low, LED_LOW);
    gpio_mode(&_led_low, PullNone);
    gpio_dir(&_led_low,  PIN_OUTPUT);
    gpio_write(&_led_low, LED_GPIO_OFF);
    
    gpio_init(&_led_mid, LED_MID);
    gpio_mode(&_led_mid, PullNone);
    gpio_dir(&_led_mid,  PIN_OUTPUT);
    gpio_write(&_led_mid, LED_GPIO_OFF);
    
    gpio_init(&_led_hig, LED_HIG);
    gpio_mode(&_led_hig, PullNone);
    gpio_dir(&_led_hig,  PIN_OUTPUT);
    gpio_write(&_led_hig, LED_GPIO_OFF);

    gpio_init(&_gps_pwr, GPSPWR_EN);
    gpio_mode(&_gps_pwr, PullNone);
    gpio_dir(&_gps_pwr,  PIN_OUTPUT);
    gpio_write(&_gps_pwr, LED_GPIO_OFF);
}

void led_net_write(uint8_t led)
{
    if(led == LED_ON)
    {
        gpio_write(&_led_net, LED_GPIO_ON);
    }
    else
    {
        gpio_write(&_led_net, LED_GPIO_OFF);
    }
}

void led_com_write(uint8_t led)
{
    if(led == LED_ON)
    {
        gpio_write(&_led_com, LED_GPIO_ON);
    }
    else
    {
        gpio_write(&_led_com, LED_GPIO_OFF);
    }
}

void led_alm_write(uint8_t led)
{
    if(led == LED_ON)
    {
        gpio_write(&_led_alm, LED_GPIO_ON);
    }
    else
    {
        gpio_write(&_led_alm, LED_GPIO_OFF);
    }
}

void led_low_write(uint8_t led)
{
    if(led == LED_ON)
    {
        gpio_write(&_led_low, LED_GPIO_ON);
    }
    else
    {
        gpio_write(&_led_low, LED_GPIO_OFF);
    }
}

void led_mid_write(uint8_t led)
{
    if(led == LED_ON)
    {
        gpio_write(&_led_mid, LED_GPIO_ON);
    }
    else
    {
        gpio_write(&_led_mid, LED_GPIO_OFF);
    }
}

void led_hig_write(uint8_t led)
{
    if(led == LED_ON)
    {
        gpio_write(&_led_hig, LED_GPIO_ON);
    }
    else
    {
        gpio_write(&_led_hig, LED_GPIO_OFF);
    }
}

void gps_pwr_ctr(uint8_t value)
{
    if(value == LED_ON)
    {
        gpio_write(&_gps_pwr, LED_GPIO_ON);
    }
    else
    {
        gpio_write(&_gps_pwr, LED_GPIO_OFF);
    }
}

/******************* restart api ************************/
void system_restart(void)
{
    NVIC_SystemReset();
}


/******************** rtc api ***************************/
time_t comm_rtc_read(void)
{
    time_t t;
    
    t = rtc_read();
    
    return t;
}

void comm_rtc_write(time_t t)
{
    rtc_write(t);
}

/******************** GPS api ***************************/

static void _gps_uart_irq_handler(uint32_t id, SerialIrq event)
{
    serial_t *serial_obj = (serial_t *)id;
    uint8_t c = 0;
        
    if(event == RxIrq)
    {
        c = serial_getc(serial_obj);
        
        gps_uart_recv(c);
    }
}

void gps_send(unsigned char *buf)
{
    int i = 0;
    while(*(buf+i))
    {
        serial_putc(&_gps_uart,*(buf+i));
        i++;
    }
}

void gps_uart_init(int baudrate)
{
    serial_init(&_gps_uart, DEBUG_TX, DEBUG_RX);//serial 3     serial 0: SCI0_TX, SCI0_RX
    serial_format(&_gps_uart, 8, ParityNone, 1);
    serial_baud(&_gps_uart, baudrate);
    serial_irq_handler(&_gps_uart, _gps_uart_irq_handler, (uint32_t)&_gps_uart);
    serial_irq_set(&_gps_uart, RxIrq, 1);
 
}


