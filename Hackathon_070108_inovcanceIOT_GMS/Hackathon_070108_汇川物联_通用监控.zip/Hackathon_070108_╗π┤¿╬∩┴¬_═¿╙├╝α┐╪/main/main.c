/*
 * main.c.
 * 2016/07/20
 * lsp
 */

#include <stdio.h>
#include "cmsis_os.h"
#include "cmsis.h"
#include "los_sys.h"
#include "los_tick.h"
#include "los_task.ph"
#include "los_config.h"
#include "los_compiler.h"
#include "version.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cpluscplus */
#endif /* __cpluscplus */
#ifdef LOS_PACK_ALIGN_8_IAR
#pragma data_alignment=8
#endif
#ifdef LOS_PACK_ALIGN_8_KEIL
#pragma pack(8)
#endif

static unsigned int g_time =0;  

UINT8 *m_aucSysMem0;
UINT32 g_sys_mem_addr_end = 0;

extern UINT8 g_ucMemStart[];
extern UINT32 osTickInit(UINT32 uwSystemClock, UINT32 uwTickPerSecond);
extern UINT32 g_uwTskMaxNum;

extern void SystemCoreClockUpdate(void);
extern void SysTick_Task(void);
extern void milisecond_tick(void);
extern  int contiki_main(void);
extern void gps_main(void);

#ifdef ICOS_PROGRAMME
extern void SysTime_Process(void);
extern void plc_main(void);
#endif

#ifdef ICOS_CONFIGURE
extern void modbus_main(void);
#endif


/*****************************************************************************
 Function    : osEnableFPU
 Description : None
 Input       : None
 Output      : None
 Return      : None
 *****************************************************************************/
void osEnableFPU(void)
{
    *(volatile UINT32 *)0xE000ED88 |= ((3UL << 10*2)|(3UL << 11*2));
    //SCB->CPACR |= ((3UL << 10*2)|(3UL << 11*2));
}

/*****************************************************************************
 Function    : osRegister
 Description : Configuring the maximum number of tasks
 Input       : None
 Output      : None
 Return      : None
 *****************************************************************************/
LITE_OS_SEC_TEXT_INIT VOID osRegister(VOID)
{
    g_uwTskMaxNum = LOSCFG_BASE_CORE_TSK_LIMIT + 1; /* Reserved 1 for IDLE */
    g_sys_mem_addr_end = (UINT32)g_ucMemStart + OS_SYS_MEM_SIZE;
    return;
}

/*****************************************************************************
 Function    : LOS_Start
 Description : Task start function
 Input       : None
 Output      : None
 Return      : LOS_OK
 *****************************************************************************/
LITE_OS_SEC_TEXT_INIT UINT32 LOS_Start()
{
    UINT32 uwRet;
#if (LOSCFG_BASE_CORE_TICK_HW_TIME == NO)
    uwRet = osTickStart();

    if (uwRet != LOS_OK)
    {
        PRINT_ERR("osTickStart error\n");
        return uwRet;
    }
    else
    {
        IOT_Debug("liteos start ok.\r\n");
    }
    
#else
    os_timer_init();
#endif
    LOS_StartToRun();

    return uwRet;
}

/*****************************************************************************
 Function    : osMain
 Description : System kernel initialization function, configure all system modules
 Input       : None
 Output      : None
 Return      : LOS_OK
 *****************************************************************************/
LITE_OS_SEC_TEXT_INIT int osMain(void)
{
    UINT32 uwRet;

    osRegister();

    uwRet = osMemSystemInit();
    if (uwRet != LOS_OK)
    {
        PRINT_ERR("osMemSystemInit error %d\n", uwRet);
        return uwRet;
    }

#if (LOSCFG_PLATFORM_HWI == YES)
    {
        osHwiInit();
    }
#endif

    uwRet =osTaskInit();
    if (uwRet != LOS_OK)
    {
        PRINT_ERR("osTaskInit error\n");
        return uwRet;
    }

#if (LOSCFG_BASE_IPC_SEM == YES)
    {
        uwRet = osSemInit();
        if (uwRet != LOS_OK)
        {
            return uwRet;
        }
    }
#endif

#if (LOSCFG_BASE_IPC_MUX == YES)
    {
        uwRet = osMuxInit();
        if (uwRet != LOS_OK)
        {
            return uwRet;
        }
    }
#endif

#if (LOSCFG_BASE_IPC_QUEUE == YES)
    {
        uwRet = osQueueInit();
        if (uwRet != LOS_OK)
        {
            PRINT_ERR("osQueueInit error\n");
            return uwRet;
        }
    }
#endif

#if (LOSCFG_BASE_CORE_SWTMR == YES)
    {
        uwRet = osSwTmrInit();
        if (uwRet != LOS_OK)
        {
            PRINT_ERR("osSwTmrInit error\n");
            return uwRet;
        }
    }
#endif

    #if(LOSCFG_BASE_CORE_TIMESLICE == YES)
    osTimesliceInit();
    #endif

    uwRet = osIdleTaskCreate();
    if (uwRet != LOS_OK) {
        return uwRet;
    }

    return LOS_OK;
}

/*****************************************************************************/
/*****************************   creat task   ********************************/
/*****************************************************************************/
void os_ms_tick_interrupt(void const *n) 
{
    g_time++;
    SysTick_Task();
    milisecond_tick();
    
#ifdef ICOS_PROGRAMME
    SysTime_Process();
#endif
}
osTimerDef(os_ms_tick, os_ms_tick_interrupt);


#ifdef ICOS_PROGRAMME
void plc_thread(void const *args) 
{
    IOT_Debug("task running: plc task\r\n");
    
    while (1) 
    {
        plc_main();
    }
}
#endif

#ifdef ICOS_CONFIGURE
void modbus_thread(void const *args) 
{
    IOT_Debug("task running: modbus task\r\n");
    
    while (1) 
    {
        modbus_main();
    }
}
#endif


void contiki_thread(void const *args) 
{
    IOT_Debug("task running: contiki task\r\n");
    
    osTimerId os_ms_timer = osTimerCreate(osTimer(os_ms_tick), osTimerPeriodic, (void *)0);
    osTimerStart(os_ms_timer, 1);

    while (1) 
    {
        contiki_main();
    }

}

void gps_thread(void const *args)
{
    IOT_Debug("task running: gps task\r\n");
    
    while (1) 
    {
        gps_main();
    }
}

void gps_thread_def(void const *argument)
{
    gps_thread("gps_thread\r\n");
}
osThreadDef(gps_thread_def,osPriorityNormal,1,512);

#ifdef ICOS_PROGRAMME
void plc_thread_def(void const *argument) 
{
    plc_thread("plc_thread\r\n");
}
osThreadDef(plc_thread_def, osPriorityNormal,1, 512);
#endif

#ifdef ICOS_CONFIGURE
void modbus_thread_def(void const *argument) 
{
    modbus_thread("modbus_thread\r\n");
}
osThreadDef(modbus_thread_def, osPriorityNormal,1, 512);
#endif


void contiki_thread_def(void const *argument) 
{
    contiki_thread("contiki_thread\r\n");
}
osThreadDef(contiki_thread_def, osPriorityNormal,1, 2048);

int main(void)
{
    IOT_Debug("\r\n\r\n======    hello huichuan    ======\r\n\r\n");
    
    SystemCoreClockUpdate();
    
    if(LOS_OK == osMain()) {
        IOT_Debug("osMain ok.\r\n");
    } else {
        IOT_Debug("osMain fail.\r\n");
    }
    
#ifdef ICOS_PROGRAMME
    if(NULL != osThreadCreate(osThread(plc_thread_def), NULL)) {
        IOT_Debug("task creat ok: plc task\r\n");
    }
#endif
    
#ifdef ICOS_CONFIGURE
    if(NULL != osThreadCreate(osThread(modbus_thread_def), NULL)) {
        IOT_Debug("task creat ok: modbus task\r\n");
    }
#endif
    
    if(NULL != osThreadCreate(osThread(contiki_thread_def), NULL)) {
        IOT_Debug("task creat ok: contiki task\r\n");
    }
    
    if(NULL != osThreadCreate(osThread(gps_thread_def), NULL)) {
        IOT_Debug("task creat ok: gps task\r\n");
    }
    
    LOS_Start();
    
    for (;;);
    
    return 0;
}

void set_sys_nvic(void)
{
    DisableFIQ();
    SCB->VTOR = NVIC_FLASH_VECTOR_ADDRESS;
    EnableFIQ();
}

#if 1
void mbed_die(void) 
{
  while (1);
}
void mbed_sdk_init(void) 
{
}
#endif

