#ifndef __VERSION_H_
#define __VERSION_H_

/********************icOS version define**************************/
#define SOFTWARE_NAME   "IOT-WL210DK"                                //��������
#define VERSION_SYS     (GPS_exist?("IOT-WL210DKG"):("IOT-WL210DK")) //�豸�ͺ�
#define VERSION_APP     "AppCollect_"
#define VERSION_VBD     "V00B01D00"                                  //�汾��
#define VERSION_LEN     9

#define set_bit(x,y)    (x) |= (1<<(y))
#define clr_bit(x,y)    (x) &= ~(1<<(y))

/**********************icOS type define***************************/
#define ICOS_PROGRAMME
//#define ICOS_CONFIGURE

/********************modbus switch define*************************/
#define MODBUS_RECV     (0)
#define MODBUS_SEND     (1)

/**********************led flash define***************************/
#define LED_OFF         (0)
#define LED_ON          (1)

/**********************debug info define**************************/
#define GPRS_DEBUG 0

#if 1
#define PPP_Info(...)    
#define PPP_Debug(...)
#define AT_CMD_Debug(...)
#define UIP_PPP_Info(...)
#define AMPM_GSM_LIB_DBG(...)
#define MODEM_Info(...)    
#define IOT_Debug(...)          printf(__VA_ARGS__)
#define MQTT_Debug(...)
#define FTP_Debug(...)          printf(__VA_ARGS__)
#define GPS_Debug(...)          printf(__VA_ARGS__)

#else
#define PPP_Info(...)           printf(__VA_ARGS__)
#define PPP_Debug(...)          printf(__VA_ARGS__)
#define AT_CMD_Debug(...)       printf(__VA_ARGS__)
#define UIP_PPP_Info(...)       printf(__VA_ARGS__)
#define AMPM_GSM_LIB_DBG(...)   printf(__VA_ARGS__)
#define MODEM_Info(...)         printf(__VA_ARGS__)
#define IOT_Debug(...)          printf(__VA_ARGS__)
#define MQTT_Debug(...)         printf(__VA_ARGS__)
#define FTP_Debug(...)          printf(__VA_ARGS__)
#define GPS_Debug(...)          printf(__VA_ARGS__)

#endif


#if defined(ICOS_PROGRAMME) && defined(ICOS_CONFIGURE)
    #error "icOS type multiple defined"
#elif defined(ICOS_PROGRAMME)
#elif defined(ICOS_CONFIGURE)
#else
    #error "icOS type not defined"
#endif

extern void DisableFIQ(void);
extern void EnableFIQ(void);

#endif /*__VERSION_H_*/
