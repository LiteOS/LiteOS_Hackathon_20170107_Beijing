#include "contiki.h"
#include "uip.h"
#include "cmsis_os.h"
#include "comm.h"
#include "app-update-software.h"

/*---------------------------------------------------------------------------*/
extern int gprs_gsm_driver_init(void);
extern void flash_ext_init(void);
extern void soft_wdt_feed(void);
extern int is_ht_gsm_at_mode(void);
/*---------------------------------------------------------------------------*/
void
log_message(char *m1, char *m2)
{
    UIP_PPP_Info("%s%s\n", m1, m2);
}
/*---------------------------------------------------------------------------*/
void
uip_log(char *m)
{
   UIP_PPP_Info("%s\n", m);
}
/*---------------------------------------------------------------------------*/
PROCESS_NAME(ftp_process);
PROCESS_NAME(app_manager_process);
PROCESS_NAME(app_collector_process);
//PROCESS_NAME(mqtt_client_process);

/*---------------------------------------------------------------------------*/
void contiki_cycle(void)
{
    // û�ڹ�װATָ��ģʽ
    if(0 == is_ht_gsm_at_mode())
    {
        process_run();
        etimer_request_poll();
    }
}

/*---------------------------------------------------------------------------*/
int contiki_main(void)
{
    process_init();

    process_start((struct process *)&etimer_process, (void *)NULL);
    process_start((struct process *)&tcpip_process, (void *)NULL);

    //external flash init
    flash_ext_init();
    
    software_bak_clear_sign();//do this every reboot?
    
    gprs_gsm_driver_init();
    
    process_start((struct process *)&app_manager_process, (void *)NULL);
    process_start((struct process *)&app_collector_process, (void *)NULL);
    //process_start((struct process *)&mqtt_client_process, (void *)NULL);
    process_start((struct process *)&ftp_process, (void *)NULL);
    
    while(1) 
    {
        soft_wdt_feed();
        contiki_cycle();
        osDelay(1);
    }

    return 0;
}
