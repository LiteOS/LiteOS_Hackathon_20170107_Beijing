1: In keilpacktool folder , there is a tool for generate keil pack
   if you want learn more, please go to web
   http://www.keil.com/pack/doc/CMSIS/Pack/html/cp_SWComponents.html
   http://www.keil.com/pack/doc/CMSIS/Pack/html/pdsc_components_pg.html#FileAttributeEnum