#pragma once

void GestureInit(void);