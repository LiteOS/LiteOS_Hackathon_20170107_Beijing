#pragma once

void BspInit(void);