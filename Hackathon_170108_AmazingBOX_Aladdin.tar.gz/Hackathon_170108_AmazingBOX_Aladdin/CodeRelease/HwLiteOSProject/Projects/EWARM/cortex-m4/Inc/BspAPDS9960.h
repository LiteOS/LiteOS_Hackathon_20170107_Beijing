#pragma once

void BspAPDS9960Init(void);
void BspAPDS9960SendTest(void);