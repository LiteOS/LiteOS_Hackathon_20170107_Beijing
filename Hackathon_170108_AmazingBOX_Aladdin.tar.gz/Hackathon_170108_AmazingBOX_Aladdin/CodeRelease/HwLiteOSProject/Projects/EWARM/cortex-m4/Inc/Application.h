#pragma once

// Application main entry
void AppInit(void);